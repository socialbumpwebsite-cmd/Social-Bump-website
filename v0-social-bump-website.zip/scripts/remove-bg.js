import sharp from "sharp";
import { existsSync, readdirSync } from "fs";

async function removePurpleBackground() {
  // Debug: check what directories exist
  const cwd = process.cwd();
  console.log("CWD:", cwd);

  // List files in cwd
  try {
    const files = readdirSync(cwd);
    console.log("Files in CWD:", files.join(", "));
  } catch (e) {
    console.log("Cannot list CWD:", e.message);
  }

  // Try multiple possible paths
  const candidates = [
    "/vercel/share/v0-project/public/logo.png",
    `${cwd}/public/logo.png`,
    `${cwd}/../public/logo.png`,
    "./public/logo.png",
    "../public/logo.png",
  ];

  let inputPath = null;
  for (const p of candidates) {
    const exists = existsSync(p);
    console.log(`Checking ${p}: ${exists}`);
    if (exists) {
      inputPath = p;
      break;
    }
  }

  if (!inputPath) {
    // Try listing /vercel directory structure
    try {
      console.log("/vercel contents:", readdirSync("/vercel").join(", "));
      console.log("/vercel/share contents:", readdirSync("/vercel/share").join(", "));
      console.log("/vercel/share/v0-project contents:", readdirSync("/vercel/share/v0-project").join(", "));
    } catch (e) {
      console.log("Cannot list /vercel:", e.message);
    }
    console.log("ERROR: Could not find logo.png at any expected path");
    return;
  }

  console.log("Found logo at:", inputPath);
  const outputPath = inputPath.replace("logo.png", "logo-transparent.png");

  const image = sharp(inputPath);
  const metadata = await image.metadata();
  console.log("Image size:", metadata.width, "x", metadata.height);

  const { data, info } = await image
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  console.log("Channels:", info.channels, "Total pixels:", info.width * info.height);

  // Sample the top-left corner pixel to get exact background purple
  const bgR = data[0];
  const bgG = data[1];
  const bgB = data[2];
  console.log(`Background color: rgb(${bgR}, ${bgG}, ${bgB})`);
  console.log(`Background hex: #${bgR.toString(16).padStart(2, "0")}${bgG.toString(16).padStart(2, "0")}${bgB.toString(16).padStart(2, "0")}`);

  // Replace purple background with transparency
  const newData = Buffer.alloc(data.length);
  const tolerance = 60;
  let transparentCount = 0;
  let keptCount = 0;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    const distance = Math.sqrt(
      (r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2
    );

    if (distance < tolerance) {
      newData[i] = 0;
      newData[i + 1] = 0;
      newData[i + 2] = 0;
      newData[i + 3] = 0;
      transparentCount++;
    } else {
      newData[i] = r;
      newData[i + 1] = g;
      newData[i + 2] = b;
      newData[i + 3] = 255;
      keptCount++;
    }
  }

  console.log(`Transparent: ${transparentCount}, Kept: ${keptCount}`);

  await sharp(newData, {
    raw: { width: info.width, height: info.height, channels: 4 },
  })
    .png()
    .toFile(outputPath);

  console.log("Saved to:", outputPath);
}

removePurpleBackground().catch(console.error);
