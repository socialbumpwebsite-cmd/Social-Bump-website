import sharp from "sharp";

const image = sharp("public/logo.png");
const { data, info } = await image.raw().toBuffer({ resolveWithObject: true });

// Sample 5x5 grid from center of image
const cx = Math.floor(info.width / 2);
const cy = Math.floor(info.height / 2);
const samples = [];

for (let dy = -2; dy <= 2; dy++) {
  for (let dx = -2; dx <= 2; dx++) {
    const x = cx + dx * 10;
    const y = cy + dy * 10;
    const idx = (y * info.width + x) * info.channels;
    samples.push({ r: data[idx], g: data[idx + 1], b: data[idx + 2] });
  }
}

// Also sample from corners of the image (background area)
const cornerOffsets = [
  { x: 20, y: 20 },
  { x: info.width - 20, y: 20 },
  { x: 20, y: info.height - 20 },
  { x: info.width - 20, y: info.height - 20 },
];

console.log("Image dimensions:", info.width, "x", info.height);
console.log("\nCenter samples:");
for (const s of samples.slice(0, 5)) {
  const hex = `#${s.r.toString(16).padStart(2, "0")}${s.g.toString(16).padStart(2, "0")}${s.b.toString(16).padStart(2, "0")}`;
  console.log(`  RGB(${s.r}, ${s.g}, ${s.b}) = ${hex}`);
}

console.log("\nCorner samples (background):");
for (const c of cornerOffsets) {
  const idx = (c.y * info.width + c.x) * info.channels;
  const r = data[idx], g = data[idx + 1], b = data[idx + 2];
  const hex = `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
  console.log(`  (${c.x},${c.y}) RGB(${r}, ${g}, ${b}) = ${hex}`);
}

// Average all background samples
const avg = samples.reduce(
  (acc, s) => ({ r: acc.r + s.r, g: acc.g + s.g, b: acc.b + s.b }),
  { r: 0, g: 0, b: 0 }
);
const n = samples.length;
const ar = Math.round(avg.r / n), ag = Math.round(avg.g / n), ab = Math.round(avg.b / n);
const avgHex = `#${ar.toString(16).padStart(2, "0")}${ag.toString(16).padStart(2, "0")}${ab.toString(16).padStart(2, "0")}`;
console.log(`\nAverage center color: RGB(${ar}, ${ag}, ${ab}) = ${avgHex}`);
