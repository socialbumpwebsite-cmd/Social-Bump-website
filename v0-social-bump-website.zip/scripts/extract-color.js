import sharp from 'sharp';

async function extractColor() {
  const response = await fetch('/images/image.png');
  const buffer = Buffer.from(await response.arrayBuffer());
  const image = sharp(buffer);
  const { width, height } = await image.metadata();
  
  // Sample from center of image background area (top-left quadrant to avoid text)
  const samplePoints = [
    { left: Math.floor(width * 0.1), top: Math.floor(height * 0.1) },
    { left: Math.floor(width * 0.1), top: Math.floor(height * 0.9) },
    { left: Math.floor(width * 0.9), top: Math.floor(height * 0.1) },
    { left: Math.floor(width * 0.05), top: Math.floor(height * 0.05) },
    { left: Math.floor(width * 0.5), top: Math.floor(height * 0.1) },
  ];
  
  for (const point of samplePoints) {
    const pixel = await image
      .extract({ left: point.left, top: point.top, width: 1, height: 1 })
      .raw()
      .toBuffer();
    
    const r = pixel[0];
    const g = pixel[1];
    const b = pixel[2];
    const hex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    console.log(`Point (${point.left}, ${point.top}): RGB(${r}, ${g}, ${b}) = ${hex}`);
  }
  
  // Also get average of a larger area in the corner
  const cornerBuffer = await image
    .extract({ left: 5, top: 5, width: 50, height: 50 })
    .raw()
    .toBuffer();
  
  let totalR = 0, totalG = 0, totalB = 0;
  const pixelCount = 50 * 50;
  for (let i = 0; i < cornerBuffer.length; i += 3) {
    totalR += cornerBuffer[i];
    totalG += cornerBuffer[i + 1];
    totalB += cornerBuffer[i + 2];
  }
  
  const avgR = Math.round(totalR / pixelCount);
  const avgG = Math.round(totalG / pixelCount);
  const avgB = Math.round(totalB / pixelCount);
  const avgHex = `#${avgR.toString(16).padStart(2, '0')}${avgG.toString(16).padStart(2, '0')}${avgB.toString(16).padStart(2, '0')}`;
  console.log(`\nAverage corner color: RGB(${avgR}, ${avgG}, ${avgB}) = ${avgHex}`);
}

extractColor().catch(console.error);
