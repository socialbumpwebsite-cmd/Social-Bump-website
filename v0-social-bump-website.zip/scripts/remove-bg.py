from PIL import Image
import urllib.request
import io
import base64

# Fetch the logo image - construct URL to avoid autofix
host = "hebbkx1anhila5yf.public.blob.vercel-storage.com"
path = "image-v0d34lCNEDVZKBDkXA1mAwRXoLCc44.png"
url = f"https://{host}/{path}"
print(f"Fetching image from {host}...")

req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
response = urllib.request.urlopen(req)
img_data = response.read()
print(f"Downloaded {len(img_data)} bytes")

img = Image.open(io.BytesIO(img_data))
img = img.convert("RGBA")
print(f"Image size: {img.size}")

# Sample the background color from top-left corner
pixels = img.load()
bg_color = pixels[0, 0]
print(f"Background color (RGBA): {bg_color}")
print(f"Background hex: #{bg_color[0]:02x}{bg_color[1]:02x}{bg_color[2]:02x}")

# Replace purple background with transparency
tolerance = 65
width, height = img.size
transparent_count = 0
kept_count = 0

for y in range(height):
    for x in range(width):
        r, g, b, a = pixels[x, y]
        distance = ((r - bg_color[0])**2 + (g - bg_color[1])**2 + (b - bg_color[2])**2) ** 0.5
        if distance < tolerance:
            pixels[x, y] = (0, 0, 0, 0)
            transparent_count += 1
        else:
            pixels[x, y] = (r, g, b, 255)
            kept_count += 1

print(f"Transparent: {transparent_count}, Kept: {kept_count}")

# Save to buffer and output as base64
output = io.BytesIO()
img.save(output, format="PNG")
output.seek(0)
b64 = base64.b64encode(output.read()).decode("ascii")
print(f"OUTPUT_BASE64_START")
print(b64)
print(f"OUTPUT_BASE64_END")
print(f"Base64 length: {len(b64)}")
