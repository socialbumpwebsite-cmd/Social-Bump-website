import Link from "next/link"
import type { Metadata } from "next"
import { ArrowUpRight, Megaphone, BarChart3, Palette, Video, PenTool, Target } from "lucide-react"

export const metadata: Metadata = {
  title: "Portfolio | Social Bump",
  description: "Explore our work and see how we've helped brands grow through content and performance marketing.",
}

const projects = [
  {
    title: "Brand Identity & Social",
    category: "Content Marketing",
    description: "Complete brand overhaul with social media strategy that increased engagement by 3x.",
    icon: Palette,
  },
  {
    title: "Performance Ad Campaigns",
    category: "Paid Marketing",
    description: "Data-driven ad campaigns across Meta and Google delivering 5x ROAS.",
    icon: Target,
  },
  {
    title: "Video Content Production",
    category: "Video Marketing",
    description: "Short-form and long-form video content that drove millions of organic views.",
    icon: Video,
  },
  {
    title: "Social Media Management",
    category: "Content Strategy",
    description: "End-to-end social media management growing communities from zero to thousands.",
    icon: Megaphone,
  },
  {
    title: "Copywriting & Blogs",
    category: "Content Writing",
    description: "SEO-optimized blog content and copy that converts visitors into customers.",
    icon: PenTool,
  },
  {
    title: "Analytics & Reporting",
    category: "Data & Insights",
    description: "Comprehensive analytics dashboards providing actionable growth insights.",
    icon: BarChart3,
  },
]

export default function PortfolioPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-primary py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary-foreground/70">
            Portfolio
          </p>
          <h1 className="mt-3 font-display text-4xl font-bold text-primary-foreground sm:text-5xl lg:text-6xl text-balance">
            Our Work
          </h1>
          <p className="mt-4 max-w-xl text-lg text-primary-foreground/80 leading-relaxed">
            A glimpse into the campaigns, content, and strategies that have driven real results for our clients.
          </p>
        </div>
      </section>

      {/* Portfolio Cards */}
      <section className="bg-background py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => {
              const Icon = project.icon
              return (
                <div
                  key={project.title}
                  className="group relative rounded-2xl border border-border bg-card p-8 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-primary/30"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
                    <Icon className="h-6 w-6" />
                  </div>
                  <p className="mt-5 text-xs font-semibold uppercase tracking-widest text-primary">
                    {project.category}
                  </p>
                  <h3 className="mt-2 font-display text-xl font-bold text-card-foreground">
                    {project.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {project.description}
                  </p>
                </div>
              )
            })}
          </div>

          {/* CTA Button */}
          <div className="mt-20 flex justify-center">
            <Link
              href="https://drive.google.com/drive/folders/1sRURf9XpM9_TbKvtIZeG7IcsPTscbKHm"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative inline-flex items-center gap-3 rounded-2xl bg-primary px-10 py-5 text-lg font-bold text-primary-foreground shadow-lg transition-all duration-300 hover:shadow-2xl hover:shadow-primary/25 hover:-translate-y-0.5 hover:scale-[1.02] active:scale-[0.98]"
            >
              View Our Portfolio
              <ArrowUpRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              <span className="absolute inset-0 rounded-2xl ring-0 ring-primary/50 transition-all duration-300 group-hover:ring-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}
