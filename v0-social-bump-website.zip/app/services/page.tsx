import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  ArrowRight,
  PenTool,
  Video,
  FileText,
  BookOpen,
  CalendarCheck,
  Target,
  Search,
  GitFork,
  LineChart,
  Rocket,
} from "lucide-react"

export const metadata: Metadata = {
  title: "Services | Social Bump",
  description:
    "Content marketing and performance marketing services to scale your brand. Strategy, reels, copywriting, Meta Ads, Google Ads, and more.",
}

const contentServices = [
  {
    icon: PenTool,
    title: "Strategy & Planning",
    description:
      "We map out a content strategy tailored to your brand, audience, and growth goals.",
  },
  {
    icon: Video,
    title: "Reels & Short-Form Content",
    description:
      "Thumb-stopping vertical video content optimised for Instagram, TikTok, and YouTube Shorts.",
  },
  {
    icon: FileText,
    title: "Copywriting",
    description:
      "Compelling captions, scripts, and web copy that resonates with your audience and drives action.",
  },
  {
    icon: BookOpen,
    title: "Brand Positioning",
    description:
      "Define your brand voice, messaging, and visual identity for maximum impact.",
  },
  {
    icon: CalendarCheck,
    title: "Platform Management",
    description:
      "End-to-end social media management including scheduling, community management, and reporting.",
  },
]

const performanceServices = [
  {
    icon: Target,
    title: "Meta Ads",
    description:
      "High-converting Facebook and Instagram ad campaigns with creative testing and audience targeting.",
  },
  {
    icon: Search,
    title: "Google Ads",
    description:
      "Search, display, and YouTube ads that capture high-intent traffic and drive conversions.",
  },
  {
    icon: GitFork,
    title: "Funnel Building",
    description:
      "Design and optimise conversion funnels that guide prospects from awareness to purchase.",
  },
  {
    icon: LineChart,
    title: "Campaign Optimisation",
    description:
      "Continuous A/B testing, audience refinement, and bid management to maximise ROAS.",
  },
  {
    icon: Rocket,
    title: "Scaling Strategy",
    description:
      "Proven playbooks to scale campaigns profitably without sacrificing efficiency.",
  },
]

export default function ServicesPage() {
  return (
    <>
      {/* Page header */}
      <section className="bg-primary py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary-foreground/70">
            Our Services
          </p>
          <h1 className="mt-3 font-display text-4xl font-bold text-primary-foreground sm:text-5xl lg:text-6xl text-balance">
            Everything you need to grow.
          </h1>
          <p className="mt-4 max-w-xl text-lg text-primary-foreground/80 leading-relaxed">
            From organic content to paid advertising, we bring strategy, creativity, and data together under one roof.
          </p>
        </div>
      </section>

      {/* Content Marketing */}
      <section className="bg-background py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-widest text-primary">
              Service 01
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold text-foreground sm:text-4xl">
              Content Marketing
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Build an audience, tell your story, and create a brand people actually care about.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {contentServices.map((service) => (
              <div
                key={service.title}
                className="rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-lg hover:border-primary/30"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <service.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-display text-lg font-bold text-card-foreground">
                  {service.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {service.description}
                </p>
              </div>
            ))}
          </div>
          <div className="mt-10">
            <Button asChild>
              <Link href="/contact">
                Get a Content Strategy
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="h-px bg-border" />
      </div>

      {/* Performance Marketing */}
      <section className="bg-background py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-widest text-primary">
              Service 02
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold text-foreground sm:text-4xl">
              Performance Marketing
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Turn ad spend into measurable revenue with campaigns engineered for conversion.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {performanceServices.map((service) => (
              <div
                key={service.title}
                className="rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-lg hover:border-primary/30"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <service.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-display text-lg font-bold text-card-foreground">
                  {service.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {service.description}
                </p>
              </div>
            ))}
          </div>
          <div className="mt-10">
            <Button asChild>
              <Link href="/contact">
                Launch Paid Campaigns
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary py-20 text-center lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <h2 className="font-display text-3xl font-bold text-primary-foreground sm:text-4xl text-balance">
            Not sure which service is right for you?
          </h2>
          <p className="mx-auto mt-4 max-w-lg text-primary-foreground/80 leading-relaxed">
            {"Book a free strategy call and we'll build a custom plan for your brand."}
          </p>
          <div className="mt-8">
            <Button
              size="lg"
              asChild
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 font-semibold"
            >
              <Link href="/contact">
                Book a Free Call
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  )
}
