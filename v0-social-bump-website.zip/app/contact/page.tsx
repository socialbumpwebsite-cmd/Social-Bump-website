"use client"

import React from "react"

import type { Metadata } from "next"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Mail, MapPin, Phone, Send } from "lucide-react"

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <>
      {/* Hero */}
      <section className="bg-primary py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary-foreground/70">
            Contact
          </p>
          <h1 className="mt-3 font-display text-4xl font-bold text-primary-foreground sm:text-5xl lg:text-6xl text-balance">
            {"Let's talk growth."}
          </h1>
          <p className="mt-4 max-w-xl text-lg text-primary-foreground/80 leading-relaxed">
            Fill in the form and our team will get back to you within 24 hours.
          </p>
        </div>
      </section>

      {/* Form */}
      <section className="bg-background py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-16 lg:grid-cols-5">
            {/* Contact info */}
            <div className="lg:col-span-2">
              <h2 className="font-display text-2xl font-bold text-foreground">
                Get in touch
              </h2>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                Whether you have a question, want to discuss a project, or just want to say hello, we would love to hear from you.
              </p>
              <div className="mt-8 flex flex-col gap-6">
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Email</p>
                    <a
                      href="mailto:its.socialbump@gmail.com"
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      its.socialbump@gmail.com
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Phone</p>
                    <div className="flex flex-col gap-1.5 mt-1">
                      <a
                        href="tel:7506021689"
                        className="text-sm text-muted-foreground hover:text-primary transition-colors"
                      >
                        <span className="font-medium text-foreground">Vighnesh</span>
                        {" \u2013 "}7506021689
                      </a>
                      <a
                        href="tel:+919136567456"
                        className="text-sm text-muted-foreground hover:text-primary transition-colors"
                      >
                        <span className="font-medium text-foreground">Shubham</span>
                        {" \u2013 "}+91 91365 67456
                      </a>
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Location</p>
                    <p className="text-sm text-muted-foreground">India (Remote-first)</p>
                  </div>
                </div>
              </div>

              {/* Social links */}
              <div className="mt-10">
                <p className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                  Follow us
                </p>
                <div className="mt-3 flex gap-4">
                  <a
                    href="#"
                    className="text-sm font-medium text-primary hover:underline"
                  >
                    Instagram
                  </a>
                  <a
                    href="#"
                    className="text-sm font-medium text-primary hover:underline"
                  >
                    LinkedIn
                  </a>
                  <a
                    href="#"
                    className="text-sm font-medium text-primary hover:underline"
                  >
                    Twitter
                  </a>
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-3">
              {submitted ? (
                <div className="flex flex-col items-center justify-center rounded-2xl border border-border bg-card p-12 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <Send className="h-6 w-6" />
                  </div>
                  <h3 className="mt-6 font-display text-2xl font-bold text-card-foreground">
                    Message Sent!
                  </h3>
                  <p className="mt-2 text-muted-foreground">
                    {"Thanks for reaching out. We'll get back to you within 24 hours."}
                  </p>
                </div>
              ) : (
                <form
                  onSubmit={handleSubmit}
                  className="rounded-2xl border border-border bg-card p-8"
                >
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div className="flex flex-col gap-2">
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        name="name"
                        placeholder="Your name"
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="you@company.com"
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-2">
                      <Label htmlFor="business">Business Name</Label>
                      <Input
                        id="business"
                        name="business"
                        placeholder="Your business"
                      />
                    </div>
                    <div className="flex flex-col gap-2">
                      <Label htmlFor="budget">Monthly Budget</Label>
                      <Select name="budget">
                        <SelectTrigger id="budget">
                          <SelectValue placeholder="Select range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="under-500">Under $500</SelectItem>
                          <SelectItem value="500-1000">$500 - $1,000</SelectItem>
                          <SelectItem value="1000-2500">$1,000 - $2,500</SelectItem>
                          <SelectItem value="2500-5000">$2,500 - $5,000</SelectItem>
                          <SelectItem value="5000-plus">$5,000+</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex flex-col gap-2 sm:col-span-2">
                      <Label htmlFor="message">Message</Label>
                      <Textarea
                        id="message"
                        name="message"
                        placeholder="Tell us about your project and goals..."
                        rows={5}
                        required
                      />
                    </div>
                  </div>
                  <div className="mt-6">
                    <Button type="submit" size="lg" className="w-full sm:w-auto">
                      Send Message
                      <Send className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
