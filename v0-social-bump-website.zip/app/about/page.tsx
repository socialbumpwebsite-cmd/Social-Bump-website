import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Target, Eye, Handshake } from "lucide-react"

export const metadata: Metadata = {
  title: "About | Social Bump",
  description:
    "Social Bump is a growth-focused marketing agency helping startups, D2C brands, and service businesses scale through integrated content and performance marketing.",
}

const values = [
  {
    icon: Target,
    title: "Results Over Vanity",
    description:
      "We measure success by impact on your bottom line, not likes and impressions.",
  },
  {
    icon: Eye,
    title: "Radical Transparency",
    description:
      "You see exactly what we see. Open dashboards, clear reporting, no fluff.",
  },
  {
    icon: Handshake,
    title: "Partnership Mindset",
    description:
      "We work as an extension of your team, not a detached vendor.",
  },
]

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-primary py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary-foreground/70">
            About Us
          </p>
          <h1 className="mt-3 font-display text-4xl font-bold text-primary-foreground sm:text-5xl lg:text-6xl text-balance">
            Growth is our language.
          </h1>
          <p className="mt-4 max-w-xl text-lg text-primary-foreground/80 leading-relaxed">
            We exist to help ambitious brands scale through the power of content and paid advertising.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="bg-background py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-3xl">
            <h2 className="font-display text-3xl font-bold text-foreground sm:text-4xl text-balance">
              Our Story
            </h2>
            <div className="mt-8 flex flex-col gap-6 text-muted-foreground leading-relaxed">
              <p>
                Social Bump is a growth-focused marketing agency helping startups, D2C brands, and service businesses scale through integrated content and performance marketing.
              </p>
              <p>
                We started with a simple observation: most brands either have great content with zero distribution strategy, or run ads with uninspiring creative. The gap between content and performance is where growth gets left on the table.
              </p>
              <p>
                So we built an agency that bridges that gap. We combine scroll-stopping content with data-driven paid campaigns to create a complete growth engine for brands ready to scale.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="bg-muted py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 text-center lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">
            Our Mission
          </p>
          <h2 className="mx-auto mt-4 max-w-2xl font-display text-3xl font-bold text-foreground sm:text-4xl text-balance">
            We focus on results, not vanity metrics.
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-muted-foreground leading-relaxed">
            Every strategy, every campaign, every piece of content is designed with one goal: measurable business growth for the brands we partner with.
          </p>
        </div>
      </section>

      {/* Values */}
      <section className="bg-background py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-widest text-primary">
              Our Values
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold text-foreground sm:text-4xl">
              What we stand for.
            </h2>
          </div>
          <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
            {values.map((value) => (
              <div
                key={value.title}
                className="rounded-2xl border border-border bg-card p-8 text-center"
              >
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <value.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-6 font-display text-lg font-bold text-card-foreground">
                  {value.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary py-20 text-center lg:py-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <h2 className="font-display text-3xl font-bold text-primary-foreground sm:text-4xl text-balance">
            {"Ready to work with us?"}
          </h2>
          <p className="mx-auto mt-4 max-w-lg text-primary-foreground/80 leading-relaxed">
            {"Let's talk about how Social Bump can become your growth partner."}
          </p>
          <div className="mt-8">
            <Button
              size="lg"
              asChild
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 font-semibold"
            >
              <Link href="/contact">
                Get In Touch
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  )
}
