import { LogoBanner } from "@/components/home/logo-banner"
import { Hero } from "@/components/home/hero"
import { WhatWeDo } from "@/components/home/what-we-do"
import { OurEdge } from "@/components/home/our-edge"
import { HowWeWork } from "@/components/home/how-we-work"
import { CtaSection } from "@/components/home/cta-section"

export default function HomePage() {
  return (
    <>
      <LogoBanner />
      <Hero />
      <WhatWeDo />
      <OurEdge />
      <HowWeWork />
      <CtaSection />
    </>
  )
}
