import Image from "next/image"

export function LogoBanner() {
  return (
    <section className="bg-primary">
      <div className="mx-auto flex justify-center px-6 pt-16 pb-8 sm:pt-20 sm:pb-10 lg:pt-24 lg:pb-12">
        <div className="relative h-40 w-72 sm:h-52 sm:w-[22rem] lg:h-64 lg:w-[28rem]">
          <Image
            src="/logo.png"
            alt="Social Bump Logo"
            fill
            className="object-contain"
            priority
          />
        </div>
      </div>
    </section>
  )
}
