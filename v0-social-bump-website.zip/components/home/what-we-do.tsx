import { Megaphone, BarChart3 } from "lucide-react"
import Link from "next/link"

const services = [
  {
    icon: Megaphone,
    title: "Content Marketing",
    description:
      "Strategy, reels, copywriting, brand storytelling, and platform management that builds your audience organically.",
  },
  {
    icon: BarChart3,
    title: "Performance Marketing",
    description:
      "Meta Ads, Google Ads, funnel strategy, and campaign optimisation that turns ad spend into measurable growth.",
  },
]

export function WhatWeDo() {
  return (
    <section className="bg-background py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">
            What We Do
          </p>
          <h2 className="mt-3 font-display text-3xl font-bold text-foreground sm:text-4xl text-balance">
            Two engines. One growth machine.
          </h2>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2">
          {services.map((service) => (
            <Link
              key={service.title}
              href="/services"
              className="group relative rounded-2xl border border-border bg-card p-8 transition-all hover:shadow-lg hover:border-primary/30"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <service.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-6 font-display text-xl font-bold text-card-foreground">
                {service.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {service.description}
              </p>
              <span className="mt-4 inline-flex items-center text-sm font-medium text-primary transition-colors group-hover:underline">
                Learn more &rarr;
              </span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
