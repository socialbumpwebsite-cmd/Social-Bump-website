const steps = [
  {
    number: "01",
    title: "Understand",
    description: "Deep-dive into your brand, audience, and business goals to build a strong foundation.",
  },
  {
    number: "02",
    title: "Strategise",
    description: "Craft a tailored content and performance marketing roadmap aligned with your objectives.",
  },
  {
    number: "03",
    title: "Execute",
    description: "Launch campaigns across channels with scroll-stopping creative and precision targeting.",
  },
  {
    number: "04",
    title: "Scale",
    description: "Analyse results, optimise relentlessly, and scale what works to maximise ROI.",
  },
]

export function HowWeWork() {
  return (
    <section className="bg-background py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary">
            How We Work
          </p>
          <h2 className="mt-3 font-display text-3xl font-bold text-foreground sm:text-4xl text-balance">
            A simple, proven process.
          </h2>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div key={step.number} className="relative">
              {index < steps.length - 1 && (
                <div className="absolute right-0 top-8 hidden h-px w-full bg-border lg:block" style={{ left: '60%', width: '80%' }} />
              )}
              <div className="relative rounded-2xl border border-border bg-card p-6">
                <span className="font-display text-4xl font-bold text-primary/20">
                  {step.number}
                </span>
                <h3 className="mt-4 font-display text-lg font-bold text-card-foreground">
                  {step.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
