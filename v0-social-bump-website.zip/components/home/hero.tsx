import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function Hero() {
  return (
    <section className="relative bg-primary overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute -top-40 -right-40 h-96 w-96 rounded-full bg-primary-foreground/5" />
      <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-primary-foreground/5" />

      <div className="relative mx-auto max-w-7xl px-6 py-24 lg:px-8 lg:py-36">
        <div className="text-center max-w-3xl mx-auto">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary-foreground/70">
            Growth-Led Marketing Agency
          </p>
          <h1 className="mt-4 font-display text-5xl font-bold tracking-tight text-primary-foreground sm:text-6xl lg:text-7xl text-balance">
            Where Content Meets Performance.
          </h1>
          <p className="mt-6 mx-auto max-w-xl text-lg leading-relaxed text-primary-foreground/80">
            We build content that captures attention and ads that turn attention into revenue.
          </p>
          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Button
              size="lg"
              asChild
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 font-semibold"
            >
              <Link href="/contact">
                Book a Strategy Call
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 bg-transparent"
            >
              <Link href="/services">View Services</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
