import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CtaSection() {
  return (
    <section className="relative bg-primary overflow-hidden">
      <div className="absolute -top-20 -left-20 h-64 w-64 rounded-full bg-primary-foreground/5" />
      <div className="absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-primary-foreground/5" />

      <div className="relative mx-auto max-w-7xl px-6 py-24 text-center lg:px-8 lg:py-32">
        <h2 className="font-display text-4xl font-bold text-primary-foreground sm:text-5xl text-balance">
          {"Let's Build Growth."}
        </h2>
        <p className="mx-auto mt-4 max-w-lg text-lg text-primary-foreground/80 leading-relaxed">
          Ready to turn content and ads into a real growth engine? Talk to us today.
        </p>
        <div className="mt-10">
          <Button
            size="lg"
            asChild
            className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 font-semibold"
          >
            <Link href="/contact">
              Contact Us
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
