import { Layers, Lightbulb, Zap, TrendingUp } from "lucide-react"

const edges = [
  {
    icon: Layers,
    title: "Content + Ads Under One Roof",
    description: "No more juggling agencies. We handle creative and paid together for cohesive growth.",
  },
  {
    icon: Lightbulb,
    title: "Creative-First Marketing",
    description: "We lead with ideas, not templates. Every campaign starts with a creative strategy.",
  },
  {
    icon: Zap,
    title: "Fast Testing & Execution",
    description: "We move fast, test early, and iterate quickly to find what actually works.",
  },
  {
    icon: TrendingUp,
    title: "Data-Driven Growth",
    description: "Every decision is backed by data. We optimise for results, not vanity metrics.",
  },
]

export function OurEdge() {
  return (
    <section className="bg-primary py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-widest text-primary-foreground/70">
            Our Edge
          </p>
          <h2 className="mt-3 font-display text-3xl font-bold text-primary-foreground sm:text-4xl text-balance">
            Why brands choose Social Bump.
          </h2>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {edges.map((edge) => (
            <div
              key={edge.title}
              className="rounded-2xl bg-primary-foreground/10 p-6 backdrop-blur-sm"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary-foreground/10 text-primary-foreground">
                <edge.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-lg font-bold text-primary-foreground">
                {edge.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-primary-foreground/70">
                {edge.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
