import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-4">
          <div className="md:col-span-2">
            <span className="font-display text-2xl font-bold">Social Bump</span>
            <p className="mt-4 max-w-sm text-sm text-background/70 leading-relaxed">
              Growth-led marketing agency. We build content that captures attention and ads that turn attention into revenue.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-background/50">
              Pages
            </h3>
            <ul className="mt-4 flex flex-col gap-3">
              <li>
                <Link href="/" className="text-sm text-background/70 hover:text-background transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-sm text-background/70 hover:text-background transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-sm text-background/70 hover:text-background transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-sm text-background/70 hover:text-background transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-background/50">
              Socials
            </h3>
            <ul className="mt-4 flex flex-col gap-3">
              <li>
                <a href="#" className="text-sm text-background/70 hover:text-background transition-colors">
                  Instagram
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-background/70 hover:text-background transition-colors">
                  LinkedIn
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-background/70 hover:text-background transition-colors">
                  Twitter / X
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-background/10 pt-8 text-center text-sm text-background/50">
          <p>&copy; {new Date().getFullYear()} Social Bump. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
